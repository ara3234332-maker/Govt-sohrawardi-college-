Govt. Sohrawardi College — Android project

এই প্রজেক্টটি ফোনের ব্রাউজার দিয়ে GitHub-এ আপলোড করে বিনামূল্যে GitHub Actions-এ APK build করার জন্য তৈরি।

APK বানানোর ধাপ:
1) GitHub-এ নিজের অ্যাকাউন্টে নতুন একটি private repository তৈরি করো।
2) এই ZIP-এর ভেতরের সব ফাইল (ZIP ফাইল নিজে নয়) repository-র মূল জায়গায় upload করো।
3) Commit changes দাও।
4) repository-র Actions ট্যাবে গিয়ে “Build Android APK” workflow নির্বাচন করো।
5) Run workflow চাপো এবং build শেষ হওয়া পর্যন্ত অপেক্ষা করো।
6) সফল হলে workflow run-এর নিচে Artifacts থেকে “Govt-Sohrawardi-College-APK” ডাউনলোড করো। ZIP খুলে app-debug.apk ইনস্টল করো।

গুরুত্বপূর্ণ:
- এটি Offline-first: রুটিন ও পরিবর্তন WebView-এর local storage-এ ফোনেই থাকে।
- Backup export/import-এর জন্য Android file picker যুক্ত করা আছে।
- অ্যাপ আনইনস্টল বা app data clear করলে local routine data মুছে যেতে পারে; আগে backup রাখবে।
- APK build করতে GitHub account লাগবে। কোনো password বা verification code কাউকে দেবে না।
- এটি debug APK; ব্যক্তিগত ব্যবহারের জন্য। Play Store প্রকাশের signed release build নয়।
